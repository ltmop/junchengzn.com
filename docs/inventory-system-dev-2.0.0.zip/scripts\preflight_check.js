#!/usr/bin/env node
/**
 * 进销存 skill 前置体检
 * 用法:
 *   node scripts/preflight_check.js       # 完整体检
 *   node scripts/preflight_check.js --quick  # 只查路径/依赖，不跑 git/进程排查
 * 或作为模块: import { preflight } from './preflight_check.js'
 */
import fs from 'node:fs'
import path from 'node:path'
import { execSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const CONFIG_PATH = path.join(__dirname, '..', 'config', 'paths.json')

function loadConfig() {
  return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'))
}

/** 解析 %APPDATA% 前缀 */
function resolveDbPath(p) {
  return p.replace(/%APPDATA%/i, process.env.APPDATA || '')
}

function check(ok, msg) {
  console.log(`${ok ? '✓' : '✗'} ${msg}`)
  return ok
}

export function preflight({ quick = false } = {}) {
  let pass = true
  const cfg = loadConfig()
  const root = cfg.paths.project_root

  console.log('=== 进销存 skill 前置体检 ===')
  pass = check(fs.existsSync(root), `项目根存在: ${root}`) && pass

  const pkg = path.join(root, 'package.json')
  if (check(fs.existsSync(pkg), 'package.json 存在')) {
    const v = JSON.parse(fs.readFileSync(pkg, 'utf8')).version
    console.log(`    当前版本: v${v}`)
  }

  pass = check(fs.existsSync(path.join(root, 'node_modules')), 'node_modules 已安装') && pass

  const dbPath = resolveDbPath(cfg.paths.data_db)
  const dbExist = fs.existsSync(dbPath)
  console.log(`${dbExist ? '✓' : '·'} 数据库 ${dbPath} ${dbExist ? '存在' : '（未创建，跑起来才有）'}`)

  if (!quick) {
    // git 工作区是否干净
    try {
      const status = execSync('git status --porcelain', { cwd: root, encoding: 'utf8' }).trim()
      if (status) {
        console.log(`⚠ 工作区有未提交改动（${status.split('\n').length} 个文件）——注意可能有并发会话在改`)
      } else {
        console.log('✓ git 工作区干净')
      }
    } catch {
      console.log('· 不是 git 仓库或 git 不可用，跳过工作区检查')
    }

    // 并发会话排查
    try {
      const proc = execSync(
        `wmic process where "CommandLine like '%claude-sidecar%' and CommandLine like '%resume%'" get CommandLine`,
        { encoding: 'utf8' },
      )
      const ids = proc.match(/resume ([a-f0-9-]{36})/g) || []
      if (ids.length > 0) {
        console.log(`⚠ 检测到 ${ids.length} 个 Claude 会话在跑——改文件前务必查 mtime，防并发覆盖`)
      } else {
        console.log('✓ 未检测到并发 Claude 会话')
      }
    } catch {
      console.log('· 无法检查并发会话（wmic 不可用）')
    }
  }

  const retryCfg = path.join(__dirname, '..', 'config', 'retry_rules.json')
  pass = check(fs.existsSync(retryCfg), 'retry_rules.json 存在') && pass

  console.log(pass ? '\n体检通过，可以动手。' : '\n体检有缺项，先补齐再动手。')
  return pass
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const quick = process.argv.includes('--quick')
  process.exit(preflight({ quick }) ? 0 : 1)
}
