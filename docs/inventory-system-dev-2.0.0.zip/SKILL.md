---
name: inventory-system-dev
version: 2.0.0
author: 阿杜
description: >
  通用进销存系统开发改造Skill（两条产品线：桌面版 Electron+React+SQLite + 手机版 Capacitor+纯HTML零构建）。
  覆盖加功能/修 bug/数据库迁移/UI 改造/打包/部署/验证全流程。当用户要改进销存系统、加功能、
  修 bug、改 UI、做数据库迁移、打包安装包、调统计口径时使用。
triggers:
  - /改进销存
  - /加功能
  - /修bug
  - /数据库迁移
  - /打包
  - 「开发进销存」
  - 「改UI」
  - 「统计口径」
  - 「进销存开发」
dependencies:
  tools:
    - 桌面版：Electron 43 + React 18 + Vite + Tailwind v4 + zustand + SQLite(WAL)
    - 手机版：Capacitor 7 + sql.js WASM + 腾讯云 ai-gateway
    - 验证：vitest / test-backend.mjs / happy-dom / playwright
  knowledge:
    - D:/A1-AI知识库/70-进销存系统项目/进销存系统使用指南.md
    - D:/A1-AI知识库/30-AI技术积累/渔具进销存系统架构.md
    - D:/A1-AI知识库/70-进销存系统项目/skills/inventory-system-dev/config/paths.json
  assets:
    - D:/A1-AI知识库/70-进销存系统项目/skills/inventory-system-dev/templates/
  model: claude-sonnet-4-5
---

# inventory-system-dev — 通用进销存系统开发改造Skill

> 生成依据：知识库 skill 规范（ops-skill-generator）| 日期：2026-08-21

## 一、概述

### 1.1 做什么
给两条产品线**加功能 / 修 bug / 做迁移 / 打包 / 部署**：
1. **桌面版**（AI智能管理进销存系统）：Electron+React，SQLite/WAL，本机数据
2. **手机版**（mobile-app-ading）：Capacitor+纯 HTML 零构建，sql.js WASM
3. 云同步：cloud-server（账户/多设备/加密）

### 1.2 为什么（解决什么问题）
- 两条线口径必须一致（统计/业务逻辑复用同一命令层）
- 老库升级不丢数据（ALTER TABLE 迁移 + 备份兜底）
- 打包/部署有固定流程，避免踩坑

### 1.3 架构（核心链路）

桌面界面(src/) → IPC(main.js/preload.cjs) → 命令层(commands/) → SQLite/WAL
手机端(/m/) → server.js → 同一命令层（口径一致）
云同步：cloud.js → cloud-server（AES-256-GCM 加密）

### 1.4 前置检查（每次动手前必做）
- [ ] 项目路径存在、node_modules 齐全
- [ ] git status 干净（防并发会话覆盖）
- [ ] 数据库在 %APPDATA%/fishing-inventory/（不在项目里找 .db）
- [ ] 验证命令可跑：npm run build / npx vitest run / node scripts/test-backend.mjs

### 1.5 错误处理原则
| 错误类型 | 处理 |
|---------|------|
| 老库缺新列 | MIGRATIONS 加 ALTER TABLE（只增不改） |
| 文件被并发改动 | 改前查 mtime + file-history，停下确认 |
| tsc 过但 build 挂 | 必须 npm run build（= tsc -b && vite build） |
| 手机端 CSP 拦 JS | /m/ 响应头用 APP_CSP（default-src 'self'） |
| 打包 ENOENT | 打包期间不动代码，重新 build 再 dist |

---

## 二、指令 — 逐步执行

### Step 1：加桌面端功能
1. 数据库：electron/db.js 的 SCHEMA_SQL 加表/列；MIGRATIONS 加迁移函数（PRAGMA table_info 判空补列）
2. 命令层：electron/commands/ 建模块 → commands.js re-export（价格用分）
3. IPC：main.js handle + preload.cjs CHANNELS 白名单（两端通道名一致）
4. 类型：src/types/index.ts 同步（tsc -b 不报错）
5. 前端：src/pages/ 建页 → App.tsx 路由 → Sidebar 入口 → appStore action

**确认点：** 页面能点进去、不白屏；npm run build + vitest + backend 全绿。

### Step 2：加手机端功能
1. electron/mobile/pages/xxx.js 建页（page('xxx', fn) 注册）
2. mobile/index.html 引入；app.js 加入口
3. 新 API：server.js INVOKE_CHANNELS 加通道（复用 commands.js，禁止另写 SQL）
4. 验证：node --check 页面文件

**确认点：** /m/ 实测页面渲染/交互正常。

### Step 3：修 bug
1. 优先 Electron 实测（BrowserWindow + executeJavaScript 查 #app 内容和 console）
2. 按 config/retry_rules.json 对号入座
3. 手机端页顶 window.onerror，JS 错红字显示

**确认点：** 复现路径修复，回归不破坏其他功能。

### Step 4：数据库迁移（安全第一）
1. 新列：MIGRATIONS 加函数（PRAGMA table_info 判空 → ALTER TABLE ADD COLUMN）
2. 新表：SCHEMA_SQL 加 CREATE TABLE IF NOT EXISTS
3. 老库重建表（改 CHECK）：建新表→INSERT SELECT→DROP→RENAME（照 migrateOldProductsTable 模式）
4. openDatabase 自愈：失败从 .pre-migration.bak 恢复重试

**确认点：** 老数据保留、新列可用、迁移失败可回退。

### Step 5：打包部署
桌面端：npm run build → node scripts/dist.cjs → release/
手机端：capacitor sync android → gradlew assembleRelease → app-release.apk
云服务器：cloud-server + pm2 start

**确认点：** 产物生成、版本号一致。

---

## 三、示例

### 示例 1：加「商品保质期」字段
1. db.js：inventory_batches 加 production_date/expiry_date（SCHEMA + MIGRATIONS）
2. 命令层：doInbound 接收 productionDate
3. 前端：入库表单加日期输入
4. 验证：vitest 迁移测试 + 实测入库

### 示例 2：手机端小数数量
1. units 表 allow_decimal 控制
2. loadAll 映射 unit_decimal 到商品
3. 前端 unitOf/validateQty 读 unit_decimal
4. 验证：1.5 斤入库/开单正确

### 示例 3：修老库升级报错
1. 查错误：CHECK constraint failed: status
2. 迁移加 status 映射（旧值→新值）
3. 验证：老库打开无报错、数据保留

---

## 四、边界情况
| 场景 | 处理 |
|------|------|
| 能处理 | 加功能/修 bug/迁移/打包/部署/统计口径 |
| 不能处理 | 云服务器部署（cloud-server 未部署）、Android 打包需环境 |
| 降级策略 | 统计口径以桌面端 commands/ 为准，手机端复用 |

## 五、资源
- 版本：2.0.0
- 桌面端：C:/Users/Administrator/Desktop/库存管理/AI智能管理进销存系统
- 手机端：D:/mobile-app-ading
- 验证：scripts/verify.js（build+vitest+backend+mobile 语法）
- 配置：config/paths.json、config/retry_rules.json

## 更新日志
- 2026-08-21：创建，按知识库 skill 规范制作（比系统版更完整）