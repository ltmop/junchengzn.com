#!/usr/bin/env node
/**
 * 进销存 skill 完整性自检
 * 用法:
 *   node tests/test_skill.js
 * 检查: SKILL.md 五部分 / frontmatter / config JSON / paths 指向存在 / scripts 可导入 / templates / requirements
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const SKILL_DIR = path.join(__dirname, '..')

let passed = 0
let failed = 0

function ok(cond, msg) {
  if (cond) {
    passed++
    console.log(`  ✓ ${msg}`)
  } else {
    failed++
    console.log(`  ✗ ${msg}`)
  }
}

function test(name, fn) {
  console.log(`\n${name}`)
  fn()
}

async function testScripts() {
  const p1 = path.join(SKILL_DIR, 'scripts', 'preflight_check.js')
  const p2 = path.join(SKILL_DIR, 'scripts', 'verify.js')
  ok(fs.existsSync(p1), 'scripts/preflight_check.js 存在')
  ok(fs.existsSync(p2), 'scripts/verify.js 存在')
  for (const f of [p1, p2]) {
    if (fs.existsSync(f)) {
      try {
        const mod = await import(pathToFileURL(f).href)
        ok(
          typeof mod.preflight === 'function' || typeof mod.verify === 'function',
          `${path.basename(f)} 可导入且有导出函数`,
        )
      } catch (e) {
        ok(false, `${path.basename(f)} 导入失败: ${e.message}`)
      }
    }
  }
}

async function main() {
  test('SKILL.md', () => {
    const f = path.join(SKILL_DIR, 'SKILL.md')
    ok(fs.existsSync(f), 'SKILL.md 存在')
    if (!fs.existsSync(f)) return
    const md = fs.readFileSync(f, 'utf8')
    ok(/^---\nname: .+/.test(md), 'frontmatter 有 name')
    ok(/version: \d+\.\d+\.\d+/.test(md), 'frontmatter 有 version')
    ok(/description: .+/.test(md), 'frontmatter 有 description')
    for (const sec of ['## 一、概述', '## 二、指令', '## 三、示例', '## 四、边界情况', '## 五、资源']) {
      ok(md.includes(sec), `SKILL.md 含「${sec}」`)
    }
  })

  test('config/', () => {
    const pathsF = path.join(SKILL_DIR, 'config', 'paths.json')
    const retryF = path.join(SKILL_DIR, 'config', 'retry_rules.json')
    ok(fs.existsSync(pathsF), 'config/paths.json 存在')
    ok(fs.existsSync(retryF), 'config/retry_rules.json 存在')
    if (fs.existsSync(pathsF)) {
      try {
        const cfg = JSON.parse(fs.readFileSync(pathsF, 'utf8'))
        ok(cfg.paths?.project_root && cfg.paths?.data_db, 'paths.json 含 project_root + data_db')
        ok(cfg.commands && cfg.commands.build, 'paths.json 含验证命令')
        ok(Array.isArray(cfg.mobile_pages) && cfg.mobile_pages.length > 0, 'paths.json 含 mobile_pages 清单')
        const root = cfg.paths.project_root
        ok(fs.existsSync(root), `项目根真实存在: ${root}`)
      } catch (e) {
        ok(false, `paths.json 解析失败: ${e.message}`)
      }
    }
    if (fs.existsSync(retryF)) {
      try {
        const r = JSON.parse(fs.readFileSync(retryF, 'utf8'))
        ok(Array.isArray(r.retry_rules) && r.retry_rules.length >= 5, 'retry_rules.json 含 >=5 条已知问题→修复映射')
        ok(r.global_rules?.max_total_retries > 0, 'retry_rules.json 有全局重试规则')
      } catch (e) {
        ok(false, `retry_rules.json 解析失败: ${e.message}`)
      }
    }
  })

  test('scripts/', () => testScripts())

  test('templates/ + requirements.txt', () => {
    ok(fs.existsSync(path.join(SKILL_DIR, 'requirements.txt')), 'requirements.txt 存在')
    ok(
      fs.existsSync(path.join(SKILL_DIR, 'templates', 'new-feature-checklist.md')),
      'templates/new-feature-checklist.md 存在',
    )
  })

  console.log(`\n=== 结果: ${passed} 通过 / ${failed} 失败 ===`)
  process.exit(failed === 0 ? 0 : 1)
}

main()
