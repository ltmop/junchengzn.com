#!/usr/bin/env node
/**
 * 进销存 skill 一条龙验证
 * 用法:
 *   node scripts/verify.js              # 全量：build + vitest + backend + mobile 语法
 *   node scripts/verify.js --quick      # 只跑 mobile 语法 + backend（改手机端时快验）
 * 或作为模块: import { verify } from './verify.js'
 */
import fs from 'node:fs'
import path from 'node:path'
import { execSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const CONFIG_PATH = path.join(__dirname, '..', 'config', 'paths.json')

function loadConfig() {
  return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'))
}

function run(cmd, cwd) {
  console.log(`\n>>> ${cmd}`)
  execSync(cmd, { cwd, stdio: 'inherit', shell: true })
}

export function verify({ quick = false } = {}) {
  const cfg = loadConfig()
  const root = cfg.paths.project_root
  if (!fs.existsSync(root)) {
    console.error(`项目根不存在: ${root}`)
    return false
  }
  try {
    // 手机端语法检查（纯浏览器脚本，不走 tsc）
    const pages = cfg.mobile_pages || []
    for (const page of pages) {
      const file = path.join(root, 'electron', 'mobile', 'pages', page)
      if (fs.existsSync(file)) run(`node --check "${file}"`, root)
    }

    // 后端断言测试
    run(cfg.commands.test_backend, root)

    if (!quick) {
      // 前端 vitest
      run(cfg.commands.test_frontend, root)
      // build = tsc -b && vite build（必须，不是 tsc --noEmit）
      run(cfg.commands.build, root)
    }
    console.log('\n=== 全部验证通过 ===')
    return true
  } catch (e) {
    console.error('\n=== 验证失败 ===')
    console.error(e.message)
    return false
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const quick = process.argv.includes('--quick')
  process.exit(verify({ quick }) ? 0 : 1)
}
