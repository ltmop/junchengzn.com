# 新功能落地清单（每次加功能照这个打勾）

> 用途：给"加功能"当脚手架，逐项打勾，别漏。做完跑 `node scripts/verify.js`。

## 前置
- [ ] 跑 `node scripts/preflight_check.js`（路径/依赖/并发会话体检）
- [ ] 改的文件 `ls -la --time-style='+%H:%M:%S'` 记下当前 mtime（防并发覆盖）

## 桌面端
- [ ] `electron/db.js` SCHEMA_SQL：新表 `CREATE TABLE IF NOT EXISTS` / 新列
- [ ] `electron/db.js` MIGRATIONS：老库迁移函数（ALTER ADD COLUMN 判空，只增不改）
- [ ] `electron/commands/` 新模块 + `electron/commands.js` re-export
- [ ] `electron/main.js` ipcMain.handle 注册
- [ ] `electron/preload.cjs` CHANNELS 白名单加通道
- [ ] `src/types/index.ts` 加字段/类型
- [ ] `src/pages/` 页面 + `src/App.tsx` 路由 + `src/components/layout/Sidebar.tsx` 入口
- [ ] `src/store/appStore.ts` action（如需）

## 手机端（如果涉及）
- [ ] `electron/mobile/pages/xxx.js` 页面（page('xxx', fn)）
- [ ] `electron/mobile/index.html` 引入脚本 + app.js 加入口
- [ ] `electron/server.js` INVOKE_CHANNELS 加通道（复用 commands，不另写 SQL）
- [ ] 数据带新字段（如 unit）时，相关 SELECT 显式带上

## 业务口径核对
- [ ] 金额单位是**分**（整数），不是元
- [ ] 商品单位：件/米，米商品数量保留 1 位小数
- [ ] 保质期商品：到期日必填；出库 FEFO；过期拦截
- [ ] 套装：一口价/总折扣二选一，折算取整误差补最后一行
- [ ] 报损：写 type='waste' 流水，成本按批次进价
- [ ] 盘点：sku 模式分摊算法与后端逐字节一致

## 验证
- [ ] `node --check` 手机端改动文件（不走 tsc）
- [ ] `node scripts/verify.js`（backend + vitest + build 全过）
- [ ] 涉及手机端：Electron 加载 /m/ 实测
- [ ] 涉及打包：升版本 → git commit+tag → `node scripts/dist.cjs`，**打包期间不改代码**
